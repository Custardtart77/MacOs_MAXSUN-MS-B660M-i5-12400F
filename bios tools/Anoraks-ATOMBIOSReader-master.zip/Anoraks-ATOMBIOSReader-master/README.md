# ATOMBIOSReader
### Generate master list of command and data tables from ATOM BIOS


Forked from:
https://github.com/kizwan/ATOMBIOSReader

Source of information:
http://git.kernel.org/cgit/linux/kernel/git/torvalds/linux.git/tree/drivers/gpu/drm/radeon/atombios.h
https://cgit.freedesktop.org/~mhopf/AtomDis/tree/indices.c

